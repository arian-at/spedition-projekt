import {data, useNavigate} from "react-router-dom";
import {useEffect, useState} from "react";
import api from "../api/axiosConfig.js";
import {AgGridReact} from "ag-grid-react";

function data2(touren){
    const tourenArr = [];
    let field = {};
    for (const tour of touren){
        field=
            {
                TID: tour.id,
                Auftrag: tour.auftrag,
                Tourplaner: tour.tourplaner,
                LKW: tour.lkw,
                Fahrer: tour.fahrer
            };
        tourenArr.push(field);
    }
    return tourenArr;
}


export default function Touren(){
    const navigate = useNavigate();
    const [rowData, setRowData] = useState([]);
    // Column Definitions: Defines the columns to be displayed.
    const [colDefs, setColDefs] = useState([
        {field: "TID"},
        {field: "Auftrag"},
        {field: "Tourplaner"},
        {field: "LKW"},
        {field: "Fahrer"}
    ]);

    useEffect(() => {
        (async () => await load())();
    }, []);

    async function load(){
        const touren = await api.get("/getTouren");
        console.log(touren.data)
        setRowData(data2(touren.data));
    }

    return (
        <div>

            <div>
                <button onClick={() => {
                    navigate("/kunden")
                }}>Kunden
                </button>

                <button onClick={() => {
                    navigate("/auftraege")
                }}>Aufträge
                </button>

                <button onClick={() => {
                    navigate("/touren")
                }}>Touren
                </button>

                <button onClick={() => {
                    navigate("/rechnungen")
                }}>Rechnungen
                </button>

                <button onClick={() => {
                    navigate("/account")
                }}>Account
                </button>

                <button onClick={() => {
                    navigate("/")
                }}>Abmelden
                </button>
            </div>

            <div
                className="ag-theme-quartz" // applying the Data Grid theme
                style={{
                    height: 500,
                    width: 900
                }}> hello
                <AgGridReact
                    rowData={rowData}
                    columnDefs={colDefs}
                />
            </div>


        </div>
    )
}