import {useNavigate} from "react-router-dom";
import {useState} from "react";
import api from "../api/axiosConfig.js"

export default function Anmeldung(){
    const navigate = useNavigate();
    const [username, setUsername] = useState("");

    async function anmeldung(){
        console.log(username)
        let bol = await api.get("/anmeldung", {params: {username: username}})
        console.log(bol.data)
        if (bol.data === true){
            navigate("/Startseite");
        }
    }

    return(
        <div>
            <span>Vorname:</span>
            <input
                type="text"
                value={username}
                onChange={(event) => {
                    setUsername(event.target.value);
                }}
            ></input>
            <button onClick={() => {
                anmeldung()
            }}>Anmelden
            </button>

            <button onClick={() => {
                navigate("/registrierung")
            }}>Registrieren
            </button>
        </div>
    )
}

/*
event.target.addEventListener("keypress", (event) => {
                        if (event.code === 'Enter') {
                            anmeldung();
                        }
                    })
 */

/*
async function anmeldung(){
        console.log(username)
        let bol = await api.get("/anmeldung", {params: {username: username}})
        console.log(bol.data)
        if (bol.data === true){
            navigate("/Kunden");
        }
    }
 */