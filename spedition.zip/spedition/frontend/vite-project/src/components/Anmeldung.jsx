import {useNavigate} from "react-router-dom";
import React, {useState} from "react";
import api from "../api/axiosConfig.js"
import axios from "axios";

function Anmeldung() {
    // State variables for form data
    const [vorname, setVorname] = useState("");
    const [passwort, setPasswort] = useState("");
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    // Handle form submission
    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            // Send POST request to the backend
            const response = await api.get("/anmeldung",{params: {username: vorname,passwort: passwort}});
            console.log("Tp angemeldet:", response.data);

            // Optionally, reset the form or show a success message
            setVorname("");
            setPasswort("");

           if(response.data === true){
               navigate("/startseite");
           } else{
               setError("Daten stimmen nicht. Bitte versuch es nochmal.");
            }
        } catch (err) {
            console.error("Error log in for Tourplaner:", err);
            setError("Anmeldung fehlgeschlagen.");
        }
    };

    return (
        <div>
            <h2>Willkommen, Tourplaner</h2>
            {error && <div style={{color: "red"}}>{error}</div>}

            <form onSubmit={handleSubmit}>
                <div>
                    <label>Vorname:</label>
                    <input
                        type="text"
                        value={vorname}
                        onChange={(e) => setVorname(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Passwort:</label>
                    <input
                        type="text"
                        value={passwort}
                        onChange={(e) => setPasswort(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Anmelden</button>
            </form>
            <div>
                <button onClick={() => {
                    navigate("/registrierung");
                }}>Registrieren</button>
            </div>
        </div>
    );
}

export default Anmeldung;