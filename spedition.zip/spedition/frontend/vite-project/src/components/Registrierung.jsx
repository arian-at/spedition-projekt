import React, { useState } from "react";
import axios from "axios";
import {useNavigate} from "react-router-dom";

function Registrierung() {
    // State variables for form data
    const [vorname, setVorname] = useState("");
    const [nachname, setNachname] = useState("");
    const [passwort, setPasswort] = useState("");
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    // Handle form submission
    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            // Send POST request to the backend
            const response = await axios.post("http://localhost:8080/registrierung", null,{params: {vorname,nachname,passwort}});
            console.log("Tp created:", response.data);

            // Optionally, reset the form or show a success message
            setVorname("");
            setNachname("");
            setPasswort("");

            navigate("/startseite");
        } catch (err) {
            console.error("Error creating Tourplaner:", err);
            setError("Failed to create Tourplaner. Please try again.");
        }
    };

    return (
        <div>
            <h2>Neuer Account</h2>
            {error && <div style={{color: "red"}}>{error}</div>}

            <form onSubmit={handleSubmit}>
                <div>
                    <label>Vorname:</label>
                    <input
                        type="text"
                        value={vorname}
                        onChange={(e) => setVorname(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Nachname:</label>
                    <input
                        type="text"
                        value={nachname}
                        onChange={(e) => setNachname(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Passwort:</label>
                    <input
                        type="text"
                        value={passwort}
                        onChange={(e) => setPasswort(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Submit</button>
            </form>
            <div>
                <button onClick={() => {
                    navigate("/");
                }}>Zurück
                </button>
            </div>
        </div>
    );
}

export default Registrierung;