import {createBrowserRouter, RouterProvider} from "react-router-dom";
import Anmeldung from "./Anmeldung.jsx";
import Kunden from "./Kunden.jsx";
import Touren from "./Touren.jsx";

//Die Klasse kann in anderen Komponenten mithilfe von useNavigate
//in buttons reingeschrieben werden, sodass beim Klicken auf
//das andere Komponent gewechselt wird
/*
Beispiel-Code dafür:
export default function Anmeldung(){
const navigate = useNavigate();
...
return{
<div>
<button onClick={()=> navigate("/")}>Abmelden</button>
...
 */
const router = createBrowserRouter(
    [
        {
            path:"/",
            element:<Anmeldung></Anmeldung>
        },
        {
            path:"/kunden",
            element:<Kunden></Kunden>
        },
        {
            path:"touren",
            element:<Touren></Touren>
        }
    ]
)

export default function Router(){
    return(
        <div>
            <RouterProvider router={router}/>
        </div>
    )
}