import api from "../api/axiosConfig";
import { AgGridReact } from 'ag-grid-react'; // React Data Grid Component
import "ag-grid-community/styles/ag-grid.css"; // Mandatory CSS required by the Data Grid
import "ag-grid-community/styles/ag-theme-quartz.css";
import {useEffect, useState} from "react"; // Optional Theme applied to the Data Grid

function data(kunden){
    const kundenArr = [];
    let field = {};
    for (const kunde of kunden){
        field=
            {
                KID: kunde.id,
                Vorname: kunde.vorname,
                Nachname: kunde.nachname,
                Telefonnummer: kunde.telefonnummer,
                Adresse: kunde.adresse,
                Land: kunde.land
            };
        kundenArr.push(field);
    }
    return kundenArr;
}

export default function Kunden() {

    const [rowData, setRowData] = useState([]);
    // Column Definitions: Defines the columns to be displayed.
    const [colDefs, setColDefs] = useState([
        {field: "KID"},
        {field: "Vorname"},
        {field: "Nachname"},
        //{field: "E-Mail"},
        {field: "Telefonnummer"},
        {field: "Adresse"},
        {field: "Land"},
    ]);

    useEffect(() => {
        (async () => await load())();
    }, []);

    async function load(){
        const kunden = await api.get("/getKunden");
        console.log(kunden)
        setRowData(data(kunden));
    }

    return (
        <div
            className="ag-theme-quartz" // applying the Data Grid theme
            style={{ height: 500,
                    width: 900}}> hello
            <AgGridReact
                rowData={rowData}
                columnDefs={colDefs}
            />
        </div>
    )
}
