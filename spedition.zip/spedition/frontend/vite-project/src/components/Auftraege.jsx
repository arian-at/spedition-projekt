import {useNavigate} from "react-router-dom";

export default function Auftraege(){
    const navigate = useNavigate();

    return (
        <div>

            <div>
                <button onClick={() => {
                    navigate("/kunden")
                }}>Kunden
                </button>

                <button onClick={() => {
                    navigate("/auftraege")
                }}>Aufträge
                </button>

                <button onClick={() => {
                    navigate("/touren")
                }}>Touren
                </button>

                <button onClick={() => {
                    navigate("/rechnungen")
                }}>Rechnungen
                </button>

                <button onClick={() => {
                    navigate("/account")
                }}>Account
                </button>

                <button onClick={() => {
                    navigate("/")
                }}>Abmelden
                </button>
            </div>


        </div>
    )
}