import {useNavigate} from "react-router-dom";
import {useEffect, useState} from "react";
import api from "../api/axiosConfig.js";
import {AgGridReact} from "ag-grid-react";
import axios from "axios";

function data(auftraege){
    const aufArr = [];
    let field = {};
    for (const auftrag of auftraege){
        field=
            {
                Kunde: auftrag.kid.id+", "+auftrag.kid.vorname+" "+auftrag.kid.nachname,
                Datum: auftrag.datum,
                Uhrzeit: auftrag.uhrzeit,
                Start: auftrag.startADID.strasse+" "+auftrag.startADID.hausnummer+", "+auftrag.startADID.plz+" "+auftrag.startADID.stadt,
                Ende: auftrag.endADID.strasse+" "+auftrag.endADID.hausnummer+", "+auftrag.endADID.plz+" "+auftrag.endADID.stadt,
                Distanz: auftrag.distanz

            };
        aufArr.push(field);
    }
    return aufArr;
}

const getFahrer = async () => {
    try {
        // Send GET request to your backend API
        const response = await api.get("/avFahrer");

        // Log the data to the console
        console.log('Fahrer:', response.data);
        holder(response.data);

    } catch (error) {
        console.error('There was an error fetching the Fahrer:', error);
    }
};

function holder(fahrer){
    const holder = fahrer;
    let array = [];
    for (let i = 0; i<50;i++){
        array.push(holder[i].vorname);
    }
    return array;
}

export default function Auftraege(){
    const navigate = useNavigate();
    const [rowData, setRowData] = useState([]);
    const [fahrer, setFahrer] = useState([]);
    // Column Definitions: Defines the columns to be displayed.
    const [colDefs, setColDefs] = useState([
        {field: "Kunde"},
        {field: "Datum"},
        {field: "Uhrzeit"},
        {field: "Start"},
        {field: "Ende"},
        {field: "Distanz"},
        {
            headerName: "Auswahl: Fahrer",
            field: "fahrer",
            cellEditor: "agSelectCellEditor",
            cellEditorParams: {
                values: fahrer,
            },
            editable: true,
        },
        {
            headerName: "Auswahl: LKW",
            field: "lkw",
            cellEditor: "agSelectCellEditor",
            cellEditorParams: {
                values: fahrer,
            },
            editable: true,
        },
    ]);

    useEffect(() => {
        (async () => await load())();
    }, []);

    async function load(){
        const auftraege = await api.get("/getAuftraege");
        console.log(auftraege.data)
        setRowData(data(auftraege.data));
        setFahrer(getFahrer());
    }

    return (
        <div>
            <div><h2>Aufräge</h2></div>
            <div>
                <button onClick={() => {
                    navigate("/kunden")
                }}>Kunden
                </button>

                <button onClick={() => {
                    navigate("/auftraege")
                }}>Aufträge
                </button>

                <button onClick={() => {
                    navigate("/touren")
                }}>Touren
                </button>

                <button onClick={() => {
                    navigate("/rechnungen")
                }}>Rechnungen
                </button>

                <button onClick={() => {
                    navigate("/account")
                }}>Account
                </button>

                <button onClick={() => {
                    navigate("/")
                }}>Abmelden
                </button>
            </div>

            <div
                className="ag-theme-quartz" // applying the Data Grid theme
                style={{
                    height: 500,
                    width: 900
                }}>
                <AgGridReact
                    rowData={rowData}
                    columnDefs={colDefs}
                />
            </div>

        </div>
    )
}