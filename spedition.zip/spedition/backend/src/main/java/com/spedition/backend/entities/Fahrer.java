package com.spedition.backend.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hibernate.annotations.ColumnDefault;

@Entity
public class Fahrer {
    @Id
    @Column(name = "FID", nullable = false)
    private Integer id;

    @Column(name = "Vorname", nullable = false, length = 100)
    private String vorname;

    @Column(name = "Nachname", nullable = false, length = 100)
    private String nachname;

    @Column(name = "Telefonnummer", nullable = false, length = 20)
    private String telefonnummer;

    @ColumnDefault("0x31")
    @Column(name = "Status", length = 1)
    private byte[] status;

    @ColumnDefault("'+49'")
    @Column(name = "Land", nullable = false, length = 10)
    private String land;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public String getTelefonnummer() {
        return telefonnummer;
    }

    public void setTelefonnummer(String telefonnummer) {
        this.telefonnummer = telefonnummer;
    }

    public byte[] getStatus() {
        return status;
    }

    public void setStatus(byte[] status) {
        this.status = status;
    }

    public String getLand() {
        return land;
    }

    public void setLand(String land) {
        this.land = land;
    }

}