package com.spedition.backend.repositories;

import com.spedition.backend.entities.Fahrer;
import org.springframework.data.repository.CrudRepository;

public interface FahrerRepository extends CrudRepository<Fahrer, Integer> {
}
