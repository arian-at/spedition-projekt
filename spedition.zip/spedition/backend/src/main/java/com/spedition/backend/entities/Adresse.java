package com.spedition.backend.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Adresse {
    @Id
    @Column(name = "ADID", nullable = false)
    private Integer id;

    @Column(name = "Strasse", nullable = false)
    private String strasse;

    @Column(name = "Hausnummer", nullable = false, length = 10)
    private String hausnummer;

    @Column(name = "PLZ", nullable = false, length = 10)
    private String plz;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStrasse() {
        return strasse;
    }

    public void setStrasse(String strasse) {
        this.strasse = strasse;
    }

    public String getHausnummer() {
        return hausnummer;
    }

    public void setHausnummer(String hausnummer) {
        this.hausnummer = hausnummer;
    }

    public String getPlz() {
        return plz;
    }

    public void setPlz(String plz) {
        this.plz = plz;
    }

}