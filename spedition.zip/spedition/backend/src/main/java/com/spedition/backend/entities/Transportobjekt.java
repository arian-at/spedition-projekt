package com.spedition.backend.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Transportobjekt {
    @Id
    @Column(name = "OID", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "Auftrag", nullable = false)
    private Auftrag auftrag;

    @Column(name = "Bezeichnung", nullable = false)
    private String bezeichnung;

    @Column(name = "Höhe", nullable = false)
    private Float hoehe;

    @Column(name = "Breite", nullable = false)
    private Float breite;

    @Column(name = "Länge", nullable = false)
    private Float laenge;

    @Column(name = "Menge", nullable = false)
    private Integer menge;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Auftrag getAuftrag() {
        return auftrag;
    }

    public void setAuftrag(Auftrag auftrag) {
        this.auftrag = auftrag;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public void setBezeichnung(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    public Float getHoehe() {
        return hoehe;
    }

    public void setHoehe(Float höhe) {
        this.hoehe = hoehe;
    }

    public Float getBreite() {
        return breite;
    }

    public void setBreite(Float breite) {
        this.breite = breite;
    }

    public Float getLaenge() {
        return laenge;
    }

    public void setLaenge(Float laenge) {
        this.laenge = laenge;
    }

    public Integer getMenge() {
        return menge;
    }

    public void setMenge(Integer menge) {
        this.menge = menge;
    }

}