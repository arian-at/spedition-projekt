package com.spedition.backend.services;

import com.spedition.backend.entities.Kunde;
import com.spedition.backend.repositories.KundenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KundenService {

    @Autowired
    public KundenRepository krepo;



    public Iterable<Kunde> getKunden() {

        System.out.println("hiiiii");
        System.out.println(krepo.findAll());
        return krepo.findAll();}
}
