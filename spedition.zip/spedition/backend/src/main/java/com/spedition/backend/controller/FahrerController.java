package com.spedition.backend.controller;

import com.spedition.backend.entities.Fahrer;
import com.spedition.backend.entities.Kunde;
import com.spedition.backend.repositories.FahrerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping(path="/")
public class FahrerController {

    @Autowired
    public FahrerRepository frepo;

    //erstmal werden alle Fahrer returned weil wir keine Fahrer haben die unavailable sind
    @GetMapping(path="/avFahrer")
    public Iterable<Fahrer> avFahrer(){return frepo.findAll();}
}
