package com.spedition.backend.controller;

import com.spedition.backend.entities.Auftrag;
import com.spedition.backend.entities.Tour;
import com.spedition.backend.repositories.AuftragRepository;
import com.spedition.backend.repositories.TourRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping(path="/")
public class AuftragController {

    @Autowired
    public AuftragRepository aurepo;

    @GetMapping(path="/getAuftraege")
    public Iterable<Auftrag> getAuftraege(){return aurepo.findAll();
    }
}
