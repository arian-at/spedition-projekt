package com.spedition.backend.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Entity
public class Rechnung {
    @Id
    @Column(name = "RID", nullable = false)
    private Integer id;

    @Column(name = "Betrag", nullable = false)
    private Double betrag;

    @Column(name = "Datum", nullable = false)
    private LocalDate datum;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "Auftrag", nullable = false)
    private Auftrag auftrag;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "Adresse", nullable = false)
    private Adresse adresse;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "Kunde", nullable = false)
    private Kunde kunde;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getBetrag() {
        return betrag;
    }

    public void setBetrag(Double betrag) {
        this.betrag = betrag;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }

    public Auftrag getAuftrag() {
        return auftrag;
    }

    public void setAuftrag(Auftrag auftrag) {
        this.auftrag = auftrag;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }

    public Kunde getKunde() {
        return kunde;
    }

    public void setKunde(Kunde kunde) {
        this.kunde = kunde;
    }

}