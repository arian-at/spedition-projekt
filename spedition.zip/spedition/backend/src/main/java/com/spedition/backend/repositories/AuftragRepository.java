package com.spedition.backend.repositories;

import com.spedition.backend.entities.Auftrag;
import org.springframework.data.repository.CrudRepository;

public interface AuftragRepository extends CrudRepository <Auftrag, Integer> {
}
