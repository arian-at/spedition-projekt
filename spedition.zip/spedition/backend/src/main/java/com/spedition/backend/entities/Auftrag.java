package com.spedition.backend.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class Auftrag {
    @Id
    @Column(name = "AID", nullable = false)
    private Integer id;

    @Column(name = "Datum", nullable = false)
    private LocalDate datum;

    @Column(name = "Uhrzeit", nullable = false)
    private LocalTime uhrzeit;

    @Column(name = "Distanz", nullable = false)
    private Float distanz;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "StartADID", nullable = false)
    private Adresse startADID;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "EndADID", nullable = false)
    private Adresse endADID;

    @Column(name = "KID", nullable = false)
    private Integer kid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }

    public LocalTime getUhrzeit() {
        return uhrzeit;
    }

    public void setUhrzeit(LocalTime uhrzeit) {
        this.uhrzeit = uhrzeit;
    }

    public Float getDistanz() {
        return distanz;
    }

    public void setDistanz(Float distanz) {
        this.distanz = distanz;
    }

    public Adresse getStartADID() {
        return startADID;
    }

    public void setStartADID(Adresse startADID) {
        this.startADID = startADID;
    }

    public Adresse getEndADID() {
        return endADID;
    }

    public void setEndADID(Adresse endADID) {
        this.endADID = endADID;
    }

    public Integer getKid() {
        return kid;
    }

    public void setKid(Integer kid) {
        this.kid = kid;
    }

}