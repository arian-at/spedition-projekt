package com.spedition.backend.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDate;

@Entity
@Table(name = "LKW")
public class Lkw {
    @Id
    @Column(name = "LID", nullable = false)
    private Integer id;

    @Column(name = "TVDatum", nullable = false)
    private LocalDate tVDatum;

    @Column(name = "Kennzeichen", nullable = false, length = 15)
    private String kennzeichen;

    @Column(name = "Höhe", nullable = false)
    private Float hoehe;

    @Column(name = "Breite", nullable = false)
    private Float breite;

    @Column(name = "Status", length = 1)
    private byte[] status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getTVDatum() {
        return tVDatum;
    }

    public void setTVDatum(LocalDate tVDatum) {
        this.tVDatum = tVDatum;
    }

    public String getKennzeichen() {
        return kennzeichen;
    }

    public void setKennzeichen(String kennzeichen) {
        this.kennzeichen = kennzeichen;
    }

    public Float getHoehe() {
        return hoehe;
    }

    public void setHoehe(Float hoehe) {
        this.hoehe = hoehe;
    }

    public Float getBreite() {
        return breite;
    }

    public void setBreite(Float breite) {
        this.breite = breite;
    }

    public byte[] getStatus() {
        return status;
    }

    public void setStatus(byte[] status) {
        this.status = status;
    }

}