package com.spedition.backend.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Tour {
    @Id
    @Column(name = "TID", nullable = false)
    private Integer id;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "Auftrag", nullable = false)
    private Auftrag auftrag;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "Tourplaner", nullable = false)
    private com.spedition.backend.entities.Tourplaner tourplaner;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "LKW", nullable = false)
    private Lkw lkw;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "Fahrer", nullable = false)
    private Fahrer fahrer;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Auftrag getAuftrag() {
        return auftrag;
    }

    public void setAuftrag(Auftrag auftrag) {
        this.auftrag = auftrag;
    }

    public com.spedition.backend.entities.Tourplaner getTourplaner() {
        return tourplaner;
    }

    public void setTourplaner(com.spedition.backend.entities.Tourplaner tourplaner) {
        this.tourplaner = tourplaner;
    }

    public Lkw getLkw() {
        return lkw;
    }

    public void setLkw(Lkw lkw) {
        this.lkw = lkw;
    }

    public Fahrer getFahrer() {
        return fahrer;
    }

    public void setFahrer(Fahrer fahrer) {
        this.fahrer = fahrer;
    }

}