package com.spedition.backend.repositories;

import com.spedition.backend.entities.Tourplaner;
import org.springframework.data.repository.CrudRepository;

public interface TourplanerRepository extends CrudRepository<Tourplaner, Integer> {
    Tourplaner countAllById(Integer id);
}
