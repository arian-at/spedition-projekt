package com.spedition.backend.repositories;

import com.spedition.backend.entities.Rechnung;
import org.springframework.data.repository.CrudRepository;

public interface RechnungRepository extends CrudRepository <Rechnung, Integer> {
}
