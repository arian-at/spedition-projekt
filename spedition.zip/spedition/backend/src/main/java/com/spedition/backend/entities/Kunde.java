package com.spedition.backend.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Kunde {
    @Id
    @Column(name = "KID", nullable = false)
    private Integer id;

    @Column(name = "Vorname", nullable = false, length = 100)
    private String vorname;

    @Column(name = "Nachname", nullable = false, length = 100)
    private String nachname;

    @Column(name = "`E-Mail`", nullable = false)
    private String eMail;

    @Column(name = "Telefonnummer", nullable = false, length = 20)
    private String telefonnummer;

    @ColumnDefault("'+49'")
    @Column(name = "Land", nullable = false, length = 10)
    private String land;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "Adresse", nullable = false)
    private Adresse adresse;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public String getEMail() {
        return eMail;
    }

    public void setEMail(String eMail) {
        this.eMail = eMail;
    }

    public String getTelefonnummer() {
        return telefonnummer;
    }

    public void setTelefonnummer(String telefonnummer) {
        this.telefonnummer = telefonnummer;
    }

    public String getLand() {
        return land;
    }

    public void setLand(String land) {
        this.land = land;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }

}