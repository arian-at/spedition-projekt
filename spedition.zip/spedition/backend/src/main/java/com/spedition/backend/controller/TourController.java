package com.spedition.backend.controller;

import com.spedition.backend.entities.Tour;
import com.spedition.backend.repositories.TourRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping(path="/")
public class TourController {

    @Autowired
    public TourRepository trepo;

    @GetMapping(path="/getTouren")
    public Iterable<Tour> getTouren(){
        return trepo.findAll();
    }
}
