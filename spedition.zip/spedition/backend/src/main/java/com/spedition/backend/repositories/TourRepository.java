package com.spedition.backend.repositories;

import com.spedition.backend.entities.Tour;
import org.springframework.data.repository.CrudRepository;

public interface TourRepository extends CrudRepository<Tour, Integer> {
}
