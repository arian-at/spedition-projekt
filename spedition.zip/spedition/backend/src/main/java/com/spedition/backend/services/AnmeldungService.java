package com.spedition.backend.services;

import com.spedition.backend.entities.Tourplaner;
import com.spedition.backend.repositories.TourplanerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class AnmeldungService {

    @Autowired
    public TourplanerRepository tprepo;

    //username solange auf Vorname und Passwort auf ID gesetzt
    //hier kann noch Code eingefügt werden, der den angemeldeten Tp speichert für die session
    public ResponseEntity<Boolean> anmeldung(String username){
        Iterable<Tourplaner> tourplaner = tprepo.findAll();

        for(Tourplaner tp : tourplaner){

            //System.out.println(tp.getVorname());
            //System.out.println(username);

            if(Objects.equals(username, tp.getVorname())){
                return ResponseEntity.ok(true);
            }
        }
        return ResponseEntity.ok(false);
    }

    public Tourplaner saveTp(Tourplaner tp) {
        long count = tprepo.count();
        int newId = (int) count+1;
        tp.setId(newId);
        return tprepo.save(tp);
    }
}
