package com.spedition.backend.services;

import com.spedition.backend.entities.Tourplaner;
import com.spedition.backend.repositories.TourplanerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class AnmeldungService {

    @Autowired
    public TourplanerRepository tprepo;

    //username solange auf Voename und Passwort auf ID gesetzt
    //hier kann noch Code eingefügt werden, der den angemeldeten Tp speichert für die session
    public Boolean anmeldung(String username){
        Iterable<Tourplaner> tourplaner = tprepo.findAll();

        for(Tourplaner tp : tourplaner){
            if(Objects.equals(tp.getVorname(), username)){
                return true;
            }
        }
        return false;
    }
}
