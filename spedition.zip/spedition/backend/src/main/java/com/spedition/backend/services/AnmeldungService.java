package com.spedition.backend.services;

import com.spedition.backend.entities.Tourplaner;
import com.spedition.backend.repositories.TourplanerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

@Service
@Transactional
public class AnmeldungService {

    @Autowired
    public TourplanerRepository tprepo;

    public Tourplaner sessionTp;

    //username solange auf Vorname und Passwort auf ID gesetzt
    //hier kann noch Code eingefügt werden, der den angemeldeten Tp speichert für die session
    public ResponseEntity<Boolean> anmeldung(String username, String passwort){
        Iterable<Tourplaner> tourplaner = tprepo.findAll();

        for(Tourplaner tp : tourplaner){

            //System.out.println(tp.getVorname());
            //System.out.println(username);

            if(Objects.equals(username, tp.getVorname()) && Objects.equals(passwort, tp.getPasswort())){
                this.sessionTp = tp;
                return ResponseEntity.ok(true);
            }
        }
        return ResponseEntity.ok(false);
    }

    @Transactional
    public Tourplaner saveTp(String vorname, String nachname, String passwort) {
//        long count = tprepo.count();
//        int newId = (int) count;
//        newId = newId+1;
        Tourplaner newTp = new Tourplaner();
//        newTp.setId(newId);
        newTp.setVorname(vorname);
        newTp.setNachname(nachname);
        newTp.setPasswort(passwort);

//        System.out.println(tprepo.count());
//        System.out.println(newId);
//        System.out.println(newTp.getId());
        this.sessionTp = newTp;
        return tprepo.save(newTp);
    }
}
