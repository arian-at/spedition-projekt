package com.spedition.backend.controller;

import com.spedition.backend.entities.Tourplaner;
import com.spedition.backend.services.AnmeldungService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@CrossOrigin
@RequestMapping(path="/")
public class AnmeldungController {

    @Autowired
    public AnmeldungService aser;

    @GetMapping(path="/anmeldung")
    public ResponseEntity<Boolean> anmeldung(@RequestParam String username){
        //aser.anmeldung(username);
        return ResponseEntity.ok(true);
    }

    @PostMapping(path="/registrierung")
    public ResponseEntity<Tourplaner> createTp(@RequestBody Tourplaner tp) {
        Tourplaner savedTp = aser.saveTp(tp);
        return new ResponseEntity<>(savedTp, HttpStatus.CREATED);
    }
}
