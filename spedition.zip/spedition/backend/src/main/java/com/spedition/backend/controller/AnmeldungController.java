package com.spedition.backend.controller;

import com.spedition.backend.entities.Tourplaner;
import com.spedition.backend.services.AnmeldungService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@CrossOrigin
@RequestMapping(path="/")
public class AnmeldungController {

    @Autowired
    public AnmeldungService aser;

    @PostMapping(path="/registrierung")
    public ResponseEntity<Tourplaner> createTp(@RequestParam(value="vorname") String vorname, @RequestParam(value="nachname") String nachname, @RequestParam(value="passwort") String passwort) {
        Tourplaner savedTp = aser.saveTp(vorname, nachname, passwort);
        return new ResponseEntity<>(savedTp, HttpStatus.CREATED);
    }

    @GetMapping(path="/anmeldung")
    public ResponseEntity<Boolean> anmeldung(@RequestParam String username, @RequestParam String passwort){
        //ResponseEntity.ok(true);
        return aser.anmeldung(username, passwort);
    }
}
