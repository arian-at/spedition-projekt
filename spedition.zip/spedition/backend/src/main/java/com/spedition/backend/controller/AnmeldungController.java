package com.spedition.backend.controller;

import com.spedition.backend.services.AnmeldungService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@CrossOrigin
@RequestMapping(path="/")
public class AnmeldungController {

    @Autowired
    public AnmeldungService aser;

    @GetMapping(path="/anmeldung")
    public Boolean anmeldung(@RequestParam String username){
        return true;
    }
}
