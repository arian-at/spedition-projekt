ALTER TABLE fahrer
    MODIFY status BLOB NULL;

ALTER TABLE lkw
    MODIFY status BLOB NULL;